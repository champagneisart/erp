<?php
/**
 * Plugin Name: CIA ERP Webhook
 * Description: Stuurt Avada-formulieren door naar Champagne is Art Studio ERP.
 * Version: 1.0.0
 * Author: Champagne is Art Studio
 */

if (!defined('ABSPATH')) {
  exit;
}

define('CIA_ERP_WEBHOOK_OPTION_URL', 'cia_erp_webhook_url');
define('CIA_ERP_WEBHOOK_OPTION_SECRET', 'cia_erp_webhook_secret');

function cia_erp_get_webhook_url(): string {
  $saved = get_option(CIA_ERP_WEBHOOK_OPTION_URL, '');
  if ($saved) {
    return rtrim($saved, '/');
  }
  // Pas aan naar jouw Vercel-URL of custom domain:
  return 'https://erp-gamma-peach.vercel.app/api/webhooks/forms';
}

function cia_erp_get_webhook_secret(): string {
  return (string) get_option(CIA_ERP_WEBHOOK_OPTION_SECRET, '');
}

function cia_erp_send_form_to_erp(array $payload): void {
  $secret = cia_erp_get_webhook_secret();
  if (!$secret) {
    error_log('[CIA ERP] WEBHOOK_SECRET niet ingesteld in WordPress → Instellingen → CIA ERP');
    return;
  }

  $response = wp_remote_post(cia_erp_get_webhook_url(), [
    'timeout' => 20,
    'headers' => [
      'Content-Type'  => 'application/json',
      'Authorization' => 'Bearer ' . $secret,
    ],
    'body' => wp_json_encode($payload),
  ]);

  if (is_wp_error($response)) {
    error_log('[CIA ERP] Webhook mislukt: ' . $response->get_error_message());
    return;
  }

  $code = wp_remote_retrieve_response_code($response);
  if ($code < 200 || $code >= 300) {
    error_log('[CIA ERP] Webhook HTTP ' . $code . ': ' . wp_remote_retrieve_body($response));
  }
}

function cia_erp_build_payload($args): array {
  $form_id = '';
  $form_data = [];
  $form_name = '';

  if (is_array($args)) {
    $form_id   = (string) ($args['form_id'] ?? $args['id'] ?? '');
    $form_data = $args['data'] ?? $args['submission'] ?? $args;
    $form_name = (string) ($args['form_name'] ?? $args['form_title'] ?? $args['title'] ?? '');
  }

  if (!is_array($form_data)) {
    $form_data = [];
  }

  return array_merge($form_data, [
    'form_id'   => $form_id,
    'form_name' => $form_name,
  ]);
}

function cia_erp_on_form_submission($args): void {
  cia_erp_send_form_to_erp(cia_erp_build_payload($args));
}

// Avada / Fusion Builder hooks (versie-afhankelijk)
add_action('fusion_form_submission', 'cia_erp_on_form_submission', 10, 1);
add_action('fusion_builder_form_submission', 'cia_erp_on_form_submission', 10, 1);

add_action('admin_menu', function () {
  add_options_page(
    'CIA ERP Webhook',
    'CIA ERP Webhook',
    'manage_options',
    'cia-erp-webhook',
    'cia_erp_settings_page'
  );
});

add_action('admin_init', function () {
  register_setting('cia_erp_webhook', CIA_ERP_WEBHOOK_OPTION_URL);
  register_setting('cia_erp_webhook', CIA_ERP_WEBHOOK_OPTION_SECRET);
});

function cia_erp_settings_page(): void {
  if (!current_user_can('manage_options')) {
    return;
  }
  ?>
  <div class="wrap">
    <h1>CIA ERP Webhook</h1>
    <form method="post" action="options.php">
      <?php settings_fields('cia_erp_webhook'); ?>
      <table class="form-table">
        <tr>
          <th>Webhook URL</th>
          <td>
            <input type="url" name="<?php echo esc_attr(CIA_ERP_WEBHOOK_OPTION_URL); ?>"
              value="<?php echo esc_attr(get_option(CIA_ERP_WEBHOOK_OPTION_URL, cia_erp_get_webhook_url())); ?>"
              class="regular-text" />
            <p class="description">Bijv. https://erp-gamma-peach.vercel.app/api/webhooks/forms</p>
          </td>
        </tr>
        <tr>
          <th>Webhook secret</th>
          <td>
            <input type="password" name="<?php echo esc_attr(CIA_ERP_WEBHOOK_OPTION_SECRET); ?>"
              value="<?php echo esc_attr(get_option(CIA_ERP_WEBHOOK_OPTION_SECRET, '')); ?>"
              class="regular-text" autocomplete="new-password" />
            <p class="description">Zelfde waarde als WEBHOOK_SECRET in Vercel.</p>
          </td>
        </tr>
      </table>
      <?php submit_button(); ?>
    </form>
  </div>
  <?php
}
