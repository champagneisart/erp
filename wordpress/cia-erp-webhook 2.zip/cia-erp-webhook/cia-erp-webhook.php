<?php
/**
 * Plugin Name: CIA ERP Webhook
 * Description: Stuurt Avada-formulieren door naar Champagne is Art Studio ERP.
 * Version: 1.1.0
 * Author: Champagne is Art Studio
 */

if (!defined('ABSPATH')) {
  exit;
}

define('CIA_ERP_WEBHOOK_OPTION_URL', 'cia_erp_webhook_url');
define('CIA_ERP_WEBHOOK_OPTION_SECRET', 'cia_erp_webhook_secret');
define('CIA_ERP_WEBHOOK_OPTION_LAST', 'cia_erp_webhook_last_status');

function cia_erp_get_webhook_url(): string {
  $saved = get_option(CIA_ERP_WEBHOOK_OPTION_URL, '');
  if ($saved) {
    return rtrim($saved, '/');
  }
  return 'https://erp-gamma-peach.vercel.app/api/webhooks/forms';
}

function cia_erp_get_webhook_secret(): string {
  return (string) get_option(CIA_ERP_WEBHOOK_OPTION_SECRET, '');
}

function cia_erp_save_last_status(string $message, bool $ok): void {
  update_option(CIA_ERP_WEBHOOK_OPTION_LAST, [
    'at' => gmdate('c'),
    'ok' => $ok,
    'message' => $message,
  ]);
}

function cia_erp_send_form_to_erp(array $payload): void {
  $secret = cia_erp_get_webhook_secret();
  if (!$secret) {
    $msg = 'Secret niet ingesteld (Instellingen → CIA ERP Webhook)';
    error_log('[CIA ERP] ' . $msg);
    cia_erp_save_last_status($msg, false);
    return;
  }

  $response = wp_remote_post(cia_erp_get_webhook_url(), [
    'timeout' => 20,
    'headers' => [
      'Content-Type'  => 'application/json',
      'Authorization' => 'Bearer ' . $secret,
    ],
    'body' => wp_json_encode($payload),
  ]);

  if (is_wp_error($response)) {
    $msg = 'Verbinding mislukt: ' . $response->get_error_message();
    error_log('[CIA ERP] ' . $msg);
    cia_erp_save_last_status($msg, false);
    return;
  }

  $code = (int) wp_remote_retrieve_response_code($response);
  $body = wp_remote_retrieve_body($response);

  if ($code < 200 || $code >= 300) {
    $msg = 'HTTP ' . $code . ': ' . wp_trim_words($body, 20, '…');
    error_log('[CIA ERP] Webhook ' . $msg);
    cia_erp_save_last_status($msg, false);
    return;
  }

  cia_erp_save_last_status('OK — doorgestuurd naar ERP (HTTP ' . $code . ')', true);
}

/**
 * Avada 3.x — officieel hook na database save (Submission → AJAX + database).
 *
 * @param array $form_data  Ingevulde velden
 * @param int   $form_post_id  WordPress post ID van het formulier
 */
function cia_erp_on_fusion_form_submission_data($form_data, $form_post_id): void {
  if (!is_array($form_data)) {
    $form_data = [];
  }

  $payload = array_merge($form_data, [
    'form_id'   => (string) ($form_data['form_id'] ?? $form_post_id),
    'form_name' => (string) ($form_data['form_name'] ?? get_the_title((int) $form_post_id)),
  ]);

  cia_erp_send_form_to_erp($payload);
}

/** Oudere / alternatieve Avada hooks (fallback) */
function cia_erp_on_legacy_submission($args): void {
  $form_id = '';
  $form_data = [];
  $form_name = '';

  if (is_array($args)) {
    $form_id   = (string) ($args['form_id'] ?? $args['id'] ?? '');
    $form_data = $args['data'] ?? $args['submission'] ?? $args;
    $form_name = (string) ($args['form_name'] ?? $args['form_title'] ?? $args['title'] ?? '');
  }

  if (!is_array($form_data)) {
    $form_data = [];
  }

  cia_erp_send_form_to_erp(array_merge($form_data, [
    'form_id'   => $form_id,
    'form_name' => $form_name,
  ]));
}

// Primair: Avada 3.4+
add_action('fusion_form_submission_data', 'cia_erp_on_fusion_form_submission_data', 10, 2);

// Fallbacks
add_action('fusion_form_submission', 'cia_erp_on_legacy_submission', 10, 1);
add_action('fusion_builder_form_submission', 'cia_erp_on_legacy_submission', 10, 1);

add_action('admin_menu', function () {
  add_options_page(
    'CIA ERP Webhook',
    'CIA ERP Webhook',
    'manage_options',
    'cia-erp-webhook',
    'cia_erp_settings_page'
  );
});

add_action('admin_init', function () {
  register_setting('cia_erp_webhook', CIA_ERP_WEBHOOK_OPTION_URL);
  register_setting('cia_erp_webhook', CIA_ERP_WEBHOOK_OPTION_SECRET);
});

function cia_erp_settings_page(): void {
  if (!current_user_can('manage_options')) {
    return;
  }

  $last = get_option(CIA_ERP_WEBHOOK_OPTION_LAST);
  ?>
  <div class="wrap">
    <h1>CIA ERP Webhook</h1>

    <?php if (is_array($last) && !empty($last['at'])) : ?>
      <div class="notice <?php echo !empty($last['ok']) ? 'notice-success' : 'notice-error'; ?> inline">
        <p>
          <strong>Laatste doorstuur-poging:</strong>
          <?php echo esc_html($last['at']); ?> —
          <?php echo esc_html((string) ($last['message'] ?? '')); ?>
        </p>
      </div>
    <?php else : ?>
      <div class="notice notice-warning inline">
        <p>Nog geen formulier doorgestuurd sinds activatie. Dien een test in op de website.</p>
      </div>
    <?php endif; ?>

    <form method="post" action="options.php">
      <?php settings_fields('cia_erp_webhook'); ?>
      <table class="form-table">
        <tr>
          <th>Webhook URL</th>
          <td>
            <input type="url" name="<?php echo esc_attr(CIA_ERP_WEBHOOK_OPTION_URL); ?>"
              value="<?php echo esc_attr(get_option(CIA_ERP_WEBHOOK_OPTION_URL, cia_erp_get_webhook_url())); ?>"
              class="regular-text" />
            <p class="description">Zonder <code>?secret=</code> — secret gaat via Bearer header.</p>
          </td>
        </tr>
        <tr>
          <th>Webhook secret</th>
          <td>
            <input type="password" name="<?php echo esc_attr(CIA_ERP_WEBHOOK_OPTION_SECRET); ?>"
              value="<?php echo esc_attr(get_option(CIA_ERP_WEBHOOK_OPTION_SECRET, '')); ?>"
              class="regular-text" autocomplete="new-password" />
            <p class="description">Zelfde waarde als WEBHOOK_SECRET in Vercel.</p>
          </td>
        </tr>
      </table>
      <?php submit_button(); ?>
    </form>

    <h2>Controleren</h2>
    <ol>
      <li>Avada: Submission type <strong>AJAX</strong>, actie <strong>Save to database</strong> (en mail).</li>
      <li>Send To URL <strong>uit</strong> in het formulier.</li>
      <li>Testformulier invullen op de website.</li>
      <li>Hierboven moet &quot;OK — doorgestuurd naar ERP&quot; verschijnen.</li>
      <li>In ERP: <strong>Instellingen → Avada webhook → Laatste ontvangen</strong>.</li>
    </ol>
  </div>
  <?php
}
